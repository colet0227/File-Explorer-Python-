# Assignment 1: File Explorer

This assignment includes a starter file and a validity checker:

* __a1.py__: Use this file as the main module for your program.
* __a1_validitychecker.py__: Run this file in the same directory as your a1.py to check your program.

Please visit the course website for a detailed overview of the assignment.
